/*
----------------------------------------------------------------------------------------------------------
              Glades Bot - Twitch Bot
Author: Julie Donaruma
Purpose: This is A Bot Developed for twitch to help counteract the Twitch follow bot raids that lessen users time in
 the channel when this happens.

NOTE: There are places to put in the password  (in configuration options at top of code )
NOTE: There are places to put the streamer name or any moderators for your channel
                ( in config options and in the stop command)
----------------------------------------------------------------------------------------------------------
*/

//Dependancies
const tmi = require('tmi.js');
const fs = require('fs');

const currentDate = new Date();
const year = currentDate.getFullYear();
const month = currentDate.getMonth() + 1;
const day = currentDate.getDate();
const filePath = `${month}_${day}_${year}.txt`;

  
// Define configuration options
const opts = {
  identity: {
    username: 'glades_bot',
    password: //Place Password
  },
  channels: [
    'silverfern__','AngelicJulie','TestJulie', 'glades_bot'
  ]
}; // End of Configuration options

// Create a client with above options
const client = new tmi.client(opts);

// Register event handlers (defined below)
client.on('message', onMessageHandler);
client.on('connected', onConnectedHandler);
client.on('subscription', onSubscription);
client.on('followed', onFollow);
client.on('error', onErrorHandler);

// Connect to Twitch:
client.connect();

// Called every time a message comes in
function onMessageHandler (target, context, msg, self) {
  if (self) { return; } // Ignore messages from the bot

  // Remove whitespace from chat message and split it into an array
  const command = msg.trim().split(' ');

  // Extract the command name and the username
  const commandName = command[0];
  const username = context['display-name'];

  // If the command is known, let's execute it
  if (commandName === '!dice') {
    const num = rollDice();
    client.say(target, `@${username}, you rolled a ${num}`);
    console.log(`* Executed ${commandName} command`);
  } else if (commandName === '!test') {
    client.say(target, `@${username}, Test Successful`);
    onFollow(target, 'testuser');
    console.log(`* Executed ${commandName} command`);
  }else if (commandName === '!stop' && (username === /* Enter streamer Name*/||
   username === /* Enter Moderator Name*/)) {
    client.say(target, "Shutting down. Goodbye!");
    client.disconnect();

    // Close the file
    if (fileDescriptor) {
      fs.close(fileDescriptor, (err) => {
        if (err) {
          console.error('Error closing file:', err);
        }// End of error if conditional
      });
    }//End of close file
  } // End of !stop command
  
 else {
    console.log(`* Unknown command ${commandName}`);
  }// End of not a Proper command 
}//End of On Message Handler

// Function called when someone follows the channel CURRENTLY IN WORK
function onFollow(channel, username) {
  // Open the file if not already opened
  if (!fileDescriptor) {
    fs.open(filePath, 'w', (err, fd) => {
      if (err) {
        console.error('Error opening file:', err);
        return;
      } // End of error if conditional
      console.log(`Opened file`);
      fileDescriptor = fd;
    });
  } //end of open file

  // Write to the file
  if (fileDescriptor) {
    fs.write(fileDescriptor, `${username}\n`, (err) => {
      if (err) {
        console.error('Error writing to file:', err);
      } //End of Error if conditional
    });
  }// End of file writing
}//End of OnFollow function

function onErrorHandler(err) {
  console.error('Error:', err);
}//End of onEventHandler

// Function called when someone subscribes to the channel
function onSubscription (channel, username, methods, message, userstate) {
  console.log(`${username} subscribed to ${channel}`);
}//End of OnSubscription

// Function called when the "dice" command is issued
function rollDice () {
  const sides = 6;
  return Math.floor(Math.random() * sides) + 1;
}//End of roll dice function

// Called every time the bot connects to Twitch chat
function onConnectedHandler(addr, port) {
  console.log(`* Connected to ${addr}:${port}`);
  // Open the file
  fs.open(filePath, 'w', (err, fd) => {
    if (err) {
      console.error('Error opening file:', err);
      return;
    } //End of Error if statement
    console.log(`Opened file`);
    fileDescriptor = fd;
  });
} //End of onConnected Handler
